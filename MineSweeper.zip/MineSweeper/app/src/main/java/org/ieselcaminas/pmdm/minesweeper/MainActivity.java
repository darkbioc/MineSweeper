package org.ieselcaminas.pmdm.minesweeper;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.FrameLayout;
import android.widget.GridLayout;

public class MainActivity extends AppCompatActivity {

    private MineButton[][] board;
    GridLayout gridLayout;
    FrameLayout frameLayout;
    private BombMatrix bombMatrix;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        gridLayout = findViewById(R.id.gridLayout);
        gridLayout.setRowCount(Singleton.sharedInstance().getNumRows());
        gridLayout.setColumnCount(Singleton.sharedInstance().getNumCols());

        board = new MineButton[Singleton.sharedInstance().getNumRows()][Singleton.sharedInstance().getNumCols()];


        for (int i = 0; i < Singleton.sharedInstance().getNumRows(); i++) {
            for (int j = 0; j < Singleton.sharedInstance().getNumCols(); j++) {
                board[i][j] = new MineButton(getApplicationContext(), i, j);

                frameLayout = new FrameLayout(this);
                BackCell backCell = new BackCell(this);
                frameLayout.addView(backCell);
                /*if (bombMatrix.getValue(i, j) == -1) {
                    BombView bomb = new BombView(this);
                    frameLayout.addView(bomb);
                    board[i][j].setAlpha(0.5f);
                } else {
                    frameLayout.addView(bombMatrix.getTextView(this, i, j));
                } */
                frameLayout.addView(board[i][j]);
                gridLayout.addView(frameLayout);

            }


        }
    }
}
