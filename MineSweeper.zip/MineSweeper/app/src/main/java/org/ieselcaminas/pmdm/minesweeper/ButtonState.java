package org.ieselcaminas.pmdm.minesweeper;

enum ButtonState {
    CLOSED, FLAG, QUESTION, OPEN
}
