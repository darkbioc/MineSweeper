package org.ieselcaminas.pmdm.minesweeper;

class BombMatrix {
}
