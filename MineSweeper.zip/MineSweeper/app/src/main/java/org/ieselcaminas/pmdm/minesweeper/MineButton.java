package org.ieselcaminas.pmdm.minesweeper;

import android.app.ActionBar;
import android.content.Context;
import android.graphics.drawable.Drawable;
import android.util.Log;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.ImageButton;
import android.widget.LinearLayout;

public class MineButton extends android.support.v7.widget.AppCompatImageButton {
    public static final int WIDTH = 20;
    public static final int HEIGHT = 20;
    private int row, col;
    private ButtonState state;


    public MineButton(Context context, int row, int col) {
        super(context);
        this.row = row;
        this.col = col;
        state = ButtonState.CLOSED;

        final float scale = getContext().getResources().getDisplayMetrics().density;
        int width = (int) (WIDTH * scale);
        int height = (int) (HEIGHT * scale);

        android.view.ViewGroup.LayoutParams params = new FrameLayout.LayoutParams(width, height);

        setLayoutParams(params);
        setBackgroundDrawable(getResources().getDrawable(R.drawable.boton));
        setScaleType(ScaleType.FIT_XY);
        setPadding(5, 5, 5, 5);

        setOnTouchListener(new OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                Log.d("checktouch", event.toString());
                if (event.getAction() == MotionEvent.ACTION_DOWN) {
                    setBackgroundDrawable(getResources().getDrawable(R.drawable.boton_pressed));
                }
                if (event.getAction() == MotionEvent.ACTION_UP) {
                    setBackgroundDrawable(getResources().getDrawable(R.drawable.boton));
                }

                return true;
            }
        });
    }


    public int getRow() {
        return row;
    }

    public int getCol() {
        return col;
    }

    public void setState(ButtonState state) {
        this.state = state;
        switch (state) {
            case FLAG:
                setImageDrawable(getResources().getDrawable(R.drawable.flag));
                setPadding(5, 5, 5, 5);
                setScaleType(ScaleType.FIT_XY);
                break;
            case QUESTION:
                setImageDrawable(getResources().getDrawable(R.drawable.question));
                setPadding(5, 5, 5, 5);
                setScaleType(ScaleType.FIT_XY);
                break;
            default:
                setImageBitmap(null);
        }
    }

    public ButtonState getState() {
        return state;
    }
}
